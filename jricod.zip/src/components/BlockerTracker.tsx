import React, { useState } from 'react';
import { db } from '../db';
import { AlertCircle, Clock, Trash2 } from 'lucide-react';
import { useLiveQuery } from 'dexie-react-hooks';

const TEAMS = ['Backend', 'Frontend', 'QA', 'DevOps', 'Design', 'Client', 'Management', 'Other'];
const IMPACTS = ['Low', 'Medium', 'High', 'Critical'] as const;

export const BlockerTracker = () => {
  const [team, setTeam] = useState(TEAMS[0]);
  const [reason, setReason] = useState('');
  const [impact, setImpact] = useState<typeof IMPACTS[number]>('Medium');

  const blockers = useLiveQuery(() => db.blockers.orderBy('startTime').reverse().toArray());

  const handleAddBlocker = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason) return;

    await db.blockers.add({
      team,
      reason,
      impact,
      startTime: new Date(),
    });

    setReason('');
  };

  const resolveBlocker = async (id: number) => {
    const blocker = await db.blockers.get(id);
    if (blocker) {
      const endTime = new Date();
      const duration = Math.floor((endTime.getTime() - new Date(blocker.startTime).getTime()) / 1000);
      await db.blockers.update(id, { endTime, duration });
    }
  };

  const deleteBlocker = async (id: number) => {
    if (confirm('Are you sure you want to delete this blocker?')) {
      await db.blockers.delete(id);
    }
  };

  return (
    <div className="space-y-8">
      <div className="bg-card border rounded-2xl p-6 shadow-sm">
        <h3 className="text-lg font-semibold mb-4">Report New Blocker</h3>
        <form onSubmit={handleAddBlocker} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Team</label>
            <select
              value={team}
              onChange={e => setTeam(e.target.value)}
              className="bg-secondary/50 border-none rounded-lg px-3 py-2 text-sm focus:ring-2 ring-primary/20"
            >
              {TEAMS.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div className="flex flex-col gap-1.5 md:col-span-2">
            <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Reason / Description</label>
            <input
              type="text"
              value={reason}
              onChange={e => setReason(e.target.value)}
              placeholder="What's holding you back?"
              className="bg-secondary/50 border-none rounded-lg px-3 py-2 text-sm focus:ring-2 ring-primary/20"
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Impact</label>
            <div className="flex gap-2">
              <select
                value={impact}
                onChange={e => setImpact(e.target.value as any)}
                className="flex-1 bg-secondary/50 border-none rounded-lg px-3 py-2 text-sm focus:ring-2 ring-primary/20"
              >
                {IMPACTS.map(i => <option key={i} value={i}>{i}</option>)}
              </select>
              <button
                type="submit"
                className="bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
              >
                Report
              </button>
            </div>
          </div>
        </form>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold px-2">Active Blockers</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {blockers?.filter(b => !b.endTime).map(blocker => (
            <div key={blocker.id} className="bg-card border-l-4 border-l-red-500 border-y border-r rounded-r-2xl p-4 flex justify-between items-start shadow-sm">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-700 uppercase tracking-tight">
                    {blocker.impact}
                  </span>
                  <span className="text-xs font-medium text-muted-foreground">{blocker.team}</span>
                </div>
                <h4 className="font-semibold">{blocker.reason}</h4>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock size={12} />
                  <span>Started at {new Date(blocker.startTime).toLocaleTimeString()}</span>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => resolveBlocker(blocker.id!)}
                  className="px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-600 text-xs font-bold hover:bg-emerald-500/20 transition-colors"
                >
                  Resolve
                </button>
                <button
                   onClick={() => deleteBlocker(blocker.id!)}
                   className="p-1.5 rounded-lg text-muted-foreground hover:text-destructive transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
          {blockers?.filter(b => !b.endTime).length === 0 && (
            <div className="col-span-full py-12 text-center border-2 border-dashed rounded-2xl text-muted-foreground">
              <AlertCircle size={32} className="mx-auto mb-2 opacity-20" />
              <p>No active blockers. Everything is smooth!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
