import React, { useState, useEffect } from 'react';
import Dexie from 'dexie';
import { db, ActivityType, Priority } from '../db';
import { Play, Square, Plus, Loader2, AlertCircle } from 'lucide-react';
import { useLiveQuery } from 'dexie-react-hooks';

const ACTIVITY_TYPES: ActivityType[] = [
  'Feature Development', 'Bug Fix', 'Refactoring', 'Testing',
  'Code Review', 'Documentation', 'Deployment', 'Research',
  'Meeting', 'Waiting', 'Break', 'Other'
];

const PRIORITIES: Priority[] = ['Low', 'Medium', 'High', 'Urgent'];

export const ActivityTracker = () => {
  const [isActive, setIsActive] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [activeActivityId, setActiveActivityId] = useState<number | null>(null);
  const [dbError, setDbError] = useState<string | null>(null);

  const [taskName, setTaskName] = useState('');
  const [project, setProject] = useState('');
  const [type, setType] = useState<ActivityType>('Feature Development');
  const [priority, setPriority] = useState<Priority>('Medium');

  // useLiveQuery handles the subscription automatically.
  // We keep it simple to avoid infinite loops.
  const activeActivity = useLiveQuery(
    () => db.activities.where('status').equals('active').first()
  );

  const recentActivities = useLiveQuery(
    () => db.activities.where('status').equals('completed').reverse().limit(5).toArray()
  );

  // Sync state when activeActivity changes
  useEffect(() => {
    if (activeActivity) {
      setIsActive(true);
      setActiveActivityId(activeActivity.id ?? null);
      setTaskName(activeActivity.taskName);
      setProject(activeActivity.project);
      setType(activeActivity.type);
      setPriority(activeActivity.priority);

      const start = new Date(activeActivity.startTime).getTime();
      const now = new Date().getTime();
      setSeconds(Math.floor((now - start) / 1000));
    } else if (activeActivity === null) {
      // Only reset if we are sure there is no active activity
      setIsActive(false);
      setActiveActivityId(null);
    }
  }, [activeActivity]);

  // Timer interval
  useEffect(() => {
    let interval: any = null;
    if (isActive) {
      interval = setInterval(() => {
        setSeconds(s => s + 1);
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isActive]);

  const handleStart = async () => {
    if (!taskName.trim()) return;
    try {
      const id = await db.activities.add({
        taskName,
        project: project || 'General',
        type,
        priority,
        status: 'active',
        startTime: new Date(),
        tags: [],
      });
      setActiveActivityId(id as number);
      setIsActive(true);
    } catch (err) {
      console.error(err);
      setDbError("Failed to start activity.");
    }
  };

  const handleStop = async () => {
    if (!activeActivityId) return;
    try {
      await db.activities.update(activeActivityId, {
        status: 'completed',
        endTime: new Date(),
        duration: seconds
      });
      setIsActive(false);
      setSeconds(0);
      setTaskName('');
      setProject('');
      setActiveActivityId(null);
    } catch (err) {
      console.error(err);
      setDbError("Failed to stop activity.");
    }
  };

  const formatTime = (sec: number) => {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleResetDB = async () => {
    if (confirm("This will FORCE DELETE all local data. Continue?")) {
      try {
        await Dexie.delete('DeveloperWorkTracker');
        window.location.reload();
      } catch (err) {
        localStorage.clear();
        window.location.reload();
      }
    }
  };

  if (dbError) {
    return (
      <div className="bg-destructive/10 border border-destructive rounded-2xl p-8 text-center">
        <AlertCircle className="mx-auto mb-4 text-destructive" size={48} />
        <h3 className="text-xl font-bold text-destructive">Database Error</h3>
        <p className="mt-2 text-sm">{dbError}</p>
        <button onClick={handleResetDB} className="mt-6 px-6 py-2 bg-destructive text-white rounded-lg font-bold">
          Force Clear & Repair
        </button>
      </div>
    );
  }

  // activeActivity is undefined while loading, null if not found
  const isDBLoading = activeActivity === undefined;

  return (
    <div className="space-y-6">
      <div className="bg-card border rounded-2xl p-8 shadow-sm">
        {isDBLoading ? (
          <div className="flex flex-col items-center justify-center py-12 text-muted-foreground text-center">
            <Loader2 className="animate-spin mb-4 text-primary" size={40} />
            <h3 className="text-lg font-semibold text-foreground">Initializing Workspace...</h3>
            <p className="max-w-xs text-sm mt-2">Connecting to local database...</p>
            <button onClick={handleResetDB} className="mt-6 text-xs underline">Stuck? Force Reset</button>
          </div>
        ) : (
          <div className="flex flex-col md:flex-row gap-8 items-center">
            <div className="flex-1 w-full space-y-4">
              <input
                type="text"
                placeholder="What are you working on?"
                value={taskName}
                onChange={(e) => setTaskName(e.target.value)}
                disabled={isActive}
                className="text-2xl font-bold bg-transparent border-none focus:ring-0 w-full placeholder:text-muted-foreground/50 disabled:opacity-80"
              />
              <div className="flex flex-wrap gap-4">
                <div className="flex flex-col gap-1.5 flex-1 min-w-[200px]">
                  <label className="text-xs font-semibold uppercase text-muted-foreground">Project</label>
                  <input
                    type="text"
                    placeholder="Project name"
                    value={project}
                    onChange={(e) => setProject(e.target.value)}
                    disabled={isActive}
                    className="bg-secondary/50 border-none rounded-lg px-3 py-2 text-sm focus:ring-2 ring-primary/20 disabled:opacity-50"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold uppercase text-muted-foreground">Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as ActivityType)}
                    disabled={isActive}
                    className="bg-secondary/50 border-none rounded-lg px-3 py-2 text-sm focus:ring-2 ring-primary/20 disabled:opacity-50"
                  >
                    {ACTIVITY_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold uppercase text-muted-foreground">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as Priority)}
                    disabled={isActive}
                    className="bg-secondary/50 border-none rounded-lg px-3 py-2 text-sm focus:ring-2 ring-primary/20 disabled:opacity-50"
                  >
                    {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
              </div>
            </div>
            <div className="flex flex-col items-center gap-4 min-w-[200px]">
              <div className="text-5xl font-mono font-bold tracking-tighter">{formatTime(seconds)}</div>
              <div className="flex gap-3">
                {!isActive ? (
                  <button onClick={handleStart} disabled={!taskName.trim()} className="flex items-center gap-2 px-6 py-3 rounded-full bg-primary text-primary-foreground font-bold shadow-lg disabled:opacity-50">
                    <Play size={20} fill="currentColor" />
                    <span>Start</span>
                  </button>
                ) : (
                  <button onClick={handleStop} className="flex items-center gap-2 px-6 py-3 rounded-full bg-destructive text-destructive-foreground font-bold shadow-lg">
                    <Square size={20} fill="currentColor" />
                    <span>Stop</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 bg-card border rounded-2xl p-6">
          <h3 className="text-lg font-semibold mb-4">Recent Activities</h3>
          <div className="space-y-4">
            {recentActivities?.map(activity => (
              <div key={activity.id} className="flex items-center gap-4 p-3 bg-secondary/20 rounded-xl">
                <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                  <Plus size={18} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm truncate">{activity.taskName}</p>
                  <p className="text-xs text-muted-foreground">{activity.project} • {activity.type}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-mono font-medium">{formatTime(activity.duration || 0)}</p>
                  <p className="text-[10px] text-muted-foreground uppercase">{activity.status}</p>
                </div>
              </div>
            ))}
            {(!recentActivities || recentActivities.length === 0) && (
              <p className="text-sm text-muted-foreground italic text-center py-8">No recent activities found.</p>
            )}
          </div>
        </div>
        <div className="bg-card border rounded-2xl p-6">
          <h3 className="text-lg font-semibold mb-4">Quick Stats</h3>
          <div className="space-y-4">
             <div className="flex justify-between items-center p-3 bg-secondary/30 rounded-xl">
               <span className="text-sm">Tasks Completed</span>
               <span className="font-semibold">{recentActivities?.length || 0}</span>
             </div>
             <div className="flex justify-between items-center p-3 bg-secondary/30 rounded-xl">
               <span className="text-sm">Total Today</span>
               <span className="font-semibold">{formatTime(recentActivities?.reduce((acc, curr) => acc + (curr.duration || 0), 0) || 0)}</span>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};
