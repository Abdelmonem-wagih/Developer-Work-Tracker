import React, { useState } from 'react';
import { FileText, Download, FileJson, Table as TableIcon, FileSpreadsheet, Loader2 } from 'lucide-react';
import { db } from '../db';

export const Reports = () => {
  const [isExporting, setIsExporting] = useState(false);

  const downloadFile = (content: string, fileName: string, contentType: string) => {
    const a = document.createElement("a");
    const file = new Blob([content], { type: contentType });
    a.href = URL.createObjectURL(file);
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  const exportToJSON = async () => {
    setIsExporting(true);
    try {
      const activities = await db.activities.toArray();
      const blockers = await db.blockers.toArray();
      const projects = await db.projects.toArray();
      const teams = await db.teams.toArray();
      const data = {
        exportDate: new Date().toISOString(),
        activities,
        blockers,
        projects,
        teams
      };
      downloadFile(JSON.stringify(data, null, 2), `work-tracker-backup-${new Date().toISOString().split('T')[0]}.json`, 'application/json');
    } catch (error) {
      console.error('Export failed:', error);
    } finally {
      setIsExporting(false);
    }
  };

  const exportToCSV = async () => {
    setIsExporting(true);
    try {
      const activities = await db.activities.toArray();
      const headers = ['Task Name', 'Project', 'Type', 'Priority', 'Status', 'Start Time', 'End Time', 'Duration (seconds)'];
      const rows = activities.map(a => [
        `"${a.taskName}"`,
        `"${a.project}"`,
        a.type,
        a.priority,
        a.status,
        a.startTime.toISOString(),
        a.endTime?.toISOString() || '',
        a.duration || 0
      ]);

      const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      downloadFile(csvContent, `activities-${new Date().toISOString().split('T')[0]}.csv`, 'text/csv');
    } catch (error) {
      console.error('Export failed:', error);
    } finally {
      setIsExporting(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const exportFormats = [
    {
      name: 'PDF Report',
      icon: <FileText className="text-red-500" />,
      desc: 'Professional PDF (Print version)',
      action: handlePrint
    },
    {
      name: 'CSV Export',
      icon: <TableIcon className="text-emerald-500" />,
      desc: 'Raw data for spreadsheet analysis',
      action: exportToCSV
    },
    {
      name: 'Excel Workbook',
      icon: <FileSpreadsheet className="text-blue-500" />,
      desc: 'Compatible with Excel (CSV format)',
      action: exportToCSV
    },
    {
      name: 'JSON Data',
      icon: <FileJson className="text-orange-500" />,
      desc: 'Complete backup of all your data',
      action: exportToJSON
    },
  ];

  return (
    <div className="space-y-8">
      <div className="bg-card border rounded-2xl p-8 text-center max-w-2xl mx-auto shadow-sm">
        <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
          {isExporting ? <Loader2 size={32} className="animate-spin" /> : <FileText size={32} />}
        </div>
        <h3 className="text-2xl font-bold mb-2">Generate Work Report</h3>
        <p className="text-muted-foreground mb-8">
          Select a format below to export your productivity data.
          PDF reports include a summary of your activities and charts.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {exportFormats.map(format => (
            <button
              key={format.name}
              onClick={format.action}
              disabled={isExporting}
              className="flex items-center gap-4 p-4 border rounded-xl hover:bg-secondary transition-all text-left group disabled:opacity-50"
            >
              <div className="p-2 bg-background rounded-lg group-hover:scale-110 transition-transform border">
                {format.icon}
              </div>
              <div>
                <p className="font-semibold text-sm">{format.name}</p>
                <p className="text-xs text-muted-foreground">{format.desc}</p>
              </div>
              <Download size={16} className="ml-auto text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
            </button>
          ))}
        </div>
      </div>

      {/* Print-only section for PDF generation */}
      <div className="hidden print:block print:p-8">
         <h1 className="text-3xl font-bold mb-4">Developer Work Report</h1>
         <p className="mb-8 text-muted-foreground">Generated on {new Date().toLocaleDateString()}</p>
         {/* In a real app, we would include more detailed statistics here for the print view */}
         <p>Please use the Dashboard and Analytics views for visual charts when printing.</p>
      </div>
    </div>
  );
};
