import Dexie, { type Table } from 'dexie';

export type ActivityType =
  | 'Feature Development'
  | 'Bug Fix'
  | 'Refactoring'
  | 'Testing'
  | 'Code Review'
  | 'Documentation'
  | 'Deployment'
  | 'Research'
  | 'Meeting'
  | 'Waiting'
  | 'Break'
  | 'Other';

export type Priority = 'Low' | 'Medium' | 'High' | 'Urgent';

export interface Activity {
  id?: number;
  type: ActivityType;
  taskName: string;
  project: string;
  epic?: string;
  userStory?: string;
  description?: string;
  priority: Priority;
  tags: string[];
  startTime: Date;
  endTime?: Date;
  duration?: number; // in seconds
  notes?: string;
  status: 'active' | 'paused' | 'completed';
}

export interface Blocker {
  id?: number;
  team: string;
  reason: string;
  startTime: Date;
  endTime?: Date;
  duration?: number;
  impact: 'Low' | 'Medium' | 'High' | 'Critical';
  notes?: string;
}

export interface Project {
  id?: number;
  name: string;
}

export interface Team {
  id?: number;
  name: string;
}

export class MyDatabase extends Dexie {
  activities!: Table<Activity>;
  blockers!: Table<Blocker>;
  projects!: Table<Project>;
  teams!: Table<Team>;

  constructor() {
    super('DeveloperWorkTracker');
    this.version(4).stores({
      activities: '++id, type, project, status, startTime',
      blockers: '++id, team, startTime',
      projects: '++id, name',
      teams: '++id, name'
    });
  }
}

export const db = new MyDatabase();

// Handle database blocking (usually when another tab is open during upgrade)
db.on('blocked', () => {
  alert('A new version of the app is available. Please close all other tabs of this application to update.');
});

// Explicitly handle open errors to prevent hanging
db.open().catch((err) => {
  console.error("Failed to open db:", err.stack || err);
});
